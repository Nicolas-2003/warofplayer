function afficher_cacher("règles-du-jeux")
{
    if(document.getElementById("règles-du-jeux").style.visibility=="hidden")
    {
        document.getElementById("règles-du-jeux").style.visibility="visible";
        document.getElementById("outon_règles-du-jeux").innerHTML='Afficher le texte';
    }
    else
    {
        document.getElementById(id).style.visibility="hidden";
        document.getElementById("bouton_règles-du-jeux").innerHTML='AfficherCacher le texte';
    }
    return true;
}